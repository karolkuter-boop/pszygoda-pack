#if !defined INCLUDE_LIGHTING_COLORS_END_COLOR
#define INCLUDE_LIGHTING_COLORS_END_COLOR

#include "/include/utility/color.glsl"

vec3 get_light_color() {
#ifdef VOID_MODE
    /* Upstream daje pomaranczowy klucz (1.00, 0.50, 0.25). W pustce ma rzezbic ksztalt,
     * a nie malowac - wiec prawie neutralny i slabszy. Kolor niesie atmosfera. */
    return from_srgb(vec3(1.00, 0.97, 0.94)) * VOID_LIGHT_I;
#else
    return from_srgb(vec3(END_LIGHT_R, END_LIGHT_G, END_LIGHT_B)) * END_LIGHT_I;
#endif
}

vec3 get_ambient_color() {
#ifdef VOID_MODE
    /* TO BYLO ZRODLO "fioletu wszedzie". Upstream: (0.75, 0.33, 1.00) razy 0.75,
     * czyli MAGENTA, a w Endzie ambient_color oswietla KAZDA powierzchnie na pelnej
     * sile - get_skylight_falloff zwraca poza overworldem twarde 1.0. Cala geometria
     * byla wiec zalana magenta niezaleznie od tego, co robi mgla.
     *
     * Dodatkowo zalanie rownomiernym ambientem kasuje kontrast, wiec nie ma sylwetek
     * ani glebi - stad "nie widac rzeczy". Neutralny i DUZO slabszy: bloki maja byc
     * szare, dokladnie jak mowi preset ("magenta nalezy do nieba, nie do blokow"). */
    return from_srgb(vec3(1.0)) * VOID_AMBIENT_I;
#else
    return from_srgb(vec3(END_AMBIENT_R, END_AMBIENT_G, END_AMBIENT_B)) *
        END_AMBIENT_I;
#endif
}

#endif
