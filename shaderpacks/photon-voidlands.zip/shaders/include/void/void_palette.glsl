#if !defined INCLUDE_VOID_VOID_PALETTE
#define INCLUDE_VOID_VOID_PALETTE

/* Paleta zjazdu przez pustke (voidstack / nalu_descent).
 *
 * Bez tego pliku caly szyb barwi sie jednym ambient_color galezi Endu, ktory w Photonie
 * jest fioletowy - 4064 bloki w jednym kolorze. Tutaj kolor i gestosc sa funkcja
 * bezwzglednej wysokosci swiata, wiec kazde pasmo ma swoja barwe, a przejscia sa ciagle.
 *
 * Wysokosc, nie odleglosc od kamery. To jest roznica miedzy "mijam warstwy" a "mam filtr
 * na obiektywie": patrzac w dol widzisz barwe nastepnego poziomu, ZANIM tam dolecisz.
 * Kolor jest zapowiedzia, nie skutkiem.
 *
 * Punkty palety zsynchronizowane z NaluDescentPreset.java (stan: 2026-07-29).
 * Kolory w sRGB, zwracane przez from_srgb.
 */

const int void_stops = 17;

// Y malejaco. linear_step z edge0 > edge1 dziala poprawnie, bo wynik jest klamrowany.
const float void_stop_y[void_stops] = float[](
     2032.0, 1776.0, 1632.0, 1344.0, 1216.0, 1088.0,  736.0,  512.0,
      336.0,   48.0, -144.0, -608.0,  -992.0, -1512.0, -1680.0, -1952.0,
    -2032.0
);

/* Trzy zasady trzymaja te palete w kupie:
 *  - chroma rosnie do makaronow, po czym wygasa w ostatnim korytarzu. Final luster
 *    jest neutralny i niemal czarny; cieple swiatlo zostaje na graczu i odbiciach.
 *  - jeden cieply wylom: bursztyn na plains_slabs, ktore preset sam opisuje jako
 *    "looks like regular Minecraft". Falszywe wspomnienie dnia; zimno ponizej bije mocniej.
 *  - zaraz po nim najnizsza chroma calego zjazdu na village_grid - dolek przed finalem.
 */
const vec3 void_stop_col[void_stops] = vec3[](
    vec3(0.10, 0.12, 0.16),  // entry_bedrock   - prawie czern, zimna
    vec3(0.16, 0.19, 0.24),  // koniec fall_3
    vec3(0.60, 0.64, 0.68),  // voidlands_plain - blada kosc, pierwszy skok
    vec3(0.26, 0.44, 0.44),  // folded_shaft    - zimny turkus
    vec3(0.20, 0.38, 0.34),  // gap_c
    vec3(0.85, 0.62, 0.32),  // plains_slabs    - bursztyn
    vec3(0.12, 0.28, 0.55),  // flood_sheet     - zimna woda
    vec3(0.08, 0.20, 0.45),  // gap_e
    vec3(0.42, 0.28, 0.18),  // structure_mass  - rdza
    vec3(0.26, 0.28, 0.26),  // village_grid    - martwa szarosc, dolek
    vec3(0.40, 0.34, 0.20),  // sign_field
    vec3(0.34, 0.30, 0.60),  // ribbed_pillars  - fiolet dopiero tutaj wchodzi
    vec3(0.30, 0.14, 0.62),  // faceted_shards
    vec3(0.55, 0.09, 0.70),  // noodle_lower
    vec3(0.04, 0.01, 0.05),  // gap_k2          - wygaszenie na poczatku dlugiej otchlani
    vec3(0.00, 0.00, 0.00),  // mirror_end      - neutralna czern
    vec3(0.00, 0.00, 0.00)   // abyss_pad       - neutralna czern
);

/* Gestosc jest pila, nie rampa. Pasma przerwy sa gestsze od pasm z trescia, wiec dzialaja
 * jak kurtyny: kolor nastepnego aktu wchodzi w kadr zanim wjedzie geometria, a struktury
 * wyjezdzaja z mleka zamiast pop-inowac. Rytm ujecia bierze sie z osrodka, nie z montazu.
 * Baza rosnie z glebokoscia, ale znacznie lagodniej niz w pierwszej wersji. */
const float void_stop_den[void_stops] = float[](
    0.25, 0.40, 0.45, 0.75, 0.80, 0.40, 0.70, 0.90,
    0.60, 0.95, 1.00, 1.10, 1.20, 1.40, 0.55, 0.18, 0.12
);

vec3 void_tint(float y) {
    vec3 c = void_stop_col[0];
    for (int i = 0; i < void_stops - 1; ++i) {
        c = mix(c, void_stop_col[i + 1],
                linear_step(void_stop_y[i], void_stop_y[i + 1], y));
    }
    return from_srgb(c) * VOID_TINT_I;
}

float void_density_mul(float y) {
    float d = void_stop_den[0];
    for (int i = 0; i < void_stops - 1; ++i) {
        d = mix(d, void_stop_den[i + 1],
                linear_step(void_stop_y[i], void_stop_y[i + 1], y));
    }
    return d;
}

#endif // INCLUDE_VOID_VOID_PALETTE
