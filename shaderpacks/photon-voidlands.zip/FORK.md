# Photon v1.3b - fork "zjazd przez pustke"

Fork pod wymiar voidstacka (Fabric 1.21.1, Iris 1.8.8). Oryginal: Photon by SixthSurge,
licencja w LICENSE - pozwala modyfikowac i redystrybuowac, warunek: LICENSE jedzie z forkiem.

## Co zmienione wzgledem upstreamu

1. `shaders/dimension.properties` (NOWY) - wymiary voidstacka kierowane do world1.
   Bez tego Iris wrzucal je na world0 i pustka renderowala sie galezia OVERWORLDU:
   z chmurami, sloncem, niebem i mgla overworldu. Chmury znikaja wylacznie przez ten plik,
   zero zmian w kodzie chmur - caly ich kod jest bramkowany makrem WORLD_OVERWORLD.

2. `shaders/include/fog/end_fog_vl.glsl` - mgla objetosciowa w calym szybie.
   Upstream modeluje kozuch wokol glownej wyspy Endu i zabija mgle czterema niezaleznymi
   bramkami: profil exp2 z polowicznym zanikiem co 7 blokow od Y 64, mnoznik zerujacy
   wszystko ponizej Y 0, plyta objetosci 0..256, oraz wygaszanie poswiaty wzgledem
   kamery powyzej Y 120. Naprawa jednej nie daje nic. Wszystkie cztery pod #ifdef VOID_MODE.
   Przy okazji: usuniety martwy texelFetch shadowtex0 (wynik nigdzie nie uzywany).

3. `shaders/include/sky/sky.glsl` - "glupstwa" w galezi Endu.
   - poprawiona literowka w strazniku include'a (INCLUDE_SKY_SKYsky -> INCLUDE_SKY_SKY)
   - czlon Mie z pomaranczowym end_sun_color byl BEZWARUNKOWY: plama "slonce za mgla"
     zostawala nawet po wylaczeniu tarczy. Teraz pod END_SUN_EFFECT.
   - gwiazdy Endu nie mialy #ifdef STARS, ktory ma galaz overworldu. Parytet przywrocony.

4. `shaders/settings.glsl` - END_SUN_EFFECT wylaczone domyslnie (opcja zostaje w menu),
   nowa sekcja opcji pustki.

5. `shaders/include/surface/material.glsl` - EYES_EMISSION_SCALE zamiast zaszytego 1.00.
   Bloom Photona nie ma progu (czysty box 6x6), a Verity swieci addytywnie przez
   RenderType.eyes - przy 1.00 wychodzi ~12.7 HDR przy bialym punkcie tonemapy 8.0,
   czyli gwarantowany bialy klosz zamiast postaci.

## Czego jeszcze NIE ma

Palety barw per pasmo. Swiadomie: dopoki nie potwierdzimy, ze osrodek istnieje w calym
szybie, nie ma czego barwic. Kolory wchodza jako drugi krok, po pierwszym spojrzeniu.

## Zanim odpalisz

`config/iris.properties` w instancji ma maxShadowRenderDistance=5 przy domyslnych 32.
To kliencki limit nakladany na shadowDistance packa. Przy 5 mapa cieni praktycznie nie
istnieje, raymarch mgly wszedzie dostaje shadow=1.0, a wtedy nie ma ani snopow, ani
sylwetek w kontrze - czyli nie ma czego oceniac. Podniesc przed pierwszym testem.

Profil: NIGDY "low" - zawiera !VL, a bez VL w Endzie nie ma zadnej mgly
(common_fog nie ma galezi WORLD_END). Uzywac high albo ultra.
