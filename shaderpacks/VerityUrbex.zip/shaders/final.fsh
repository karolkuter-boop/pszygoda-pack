#version 120
/*
 * VerityUrbex — final: NOCNY URBEX TONEMAP (zadania 5–6).
 *
 * Pipeline (na obrazie po composite = scena + snop latarki):
 *   ekspozycja → shadow-crush + zimna tonacja cieni (zależne od jasności otoczenia)
 *   → krzywa kontrastu wokół szarości → filmic ACES → winieta → subtelny film grain.
 * Cel: nocny urbex look z referencji (mocny kontrast, zimne cienie), przy ZACHOWANIU jasności i
 * ciepłej barwy snopu latarki (ACES i tak chroni highlighty; crush działa tylko w cieniach).
 *
 * (c) 2026 FFTV — All Rights Reserved.
 */
#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;

varying vec2 texcoord;

const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);

// Filmic ACES (aproksymacja Narkowicza) — chroni highlighty (latarka zostaje jasna).
vec3 acesFilmic(vec3 x) {
    const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;

    // Ekspozycja
    col *= URBEX_EXPOSURE;

    // Maska cieni z jasności otoczenia (1 w cieniach, 0 w średnich/jasnych).
    float lum = dot(col, LUMA);
    float shadow = 1.0 - smoothstep(0.0, 0.35, lum);

    // Shadow-crush: przygaś cienie (mocniejsza czerń).
    col *= mix(1.0, 1.0 - URBEX_SHADOW_CRUSH, shadow);

    // Zimna tonacja cieni (urbex): lekko niebieskie cienie, highlighty bez zmian.
    vec3 cold = vec3(0.82, 0.94, 1.18);
    col = mix(col, col * cold, shadow * URBEX_COLD_SHADOWS);

    // Krzywa kontrastu wokół liniowej szarości ~0.18.
    col = mix(vec3(0.18), col, URBEX_CONTRAST);
    col = max(col, vec3(0.0));

    // Filmic tonemap (przełącznik w panelu Iris).
#ifdef TONEMAP_ACES
    col = acesFilmic(col);
#else
    col = clamp(col, 0.0, 1.0);
#endif

    // Winieta (przyciemnij rogi).
    float d = length(texcoord - 0.5);
    float vig = mix(1.0, smoothstep(0.90, 0.35, d), VIGNETTE);
    col *= vig;

    // Subtelny film grain (animowany frameTimeCounter).
    float g = hash21(texcoord * vec2(viewWidth, viewHeight) + fract(frameTimeCounter) * 60.0);
    col += (g - 0.5) * FILM_GRAIN;

    gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
