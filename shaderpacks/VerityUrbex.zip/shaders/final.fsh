#version 120
/*
 * VerityUrbex — final: NOCNY URBEX TONEMAP (zadania 5–6).
 *
 * Pipeline (na obrazie po composite = scena + snop latarki):
 *   ekspozycja → shadow-crush + zimna tonacja cieni (zależne od jasności otoczenia)
 *   → krzywa kontrastu wokół szarości → filmic ACES → winieta → subtelny film grain.
 * Cel: nocny urbex look z referencji (mocny kontrast, zimne cienie), przy ZACHOWANIU jasności i
 * ciepłej barwy snopu latarki (ACES i tak chroni highlighty; crush działa tylko w cieniach).
 *
 * (c) 2026 FFTV — All Rights Reserved.
 */
#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTimeCounter;
uniform int worldTime;              // czas świata w tickach (0..24000) — do bramki dzień/noc
uniform mat4 gbufferProjectionInverse; // do rekonstrukcji kierunku promienia (maska snopu latarki)
uniform int heldItemId;             // most latarki (item.properties) — czy liczyć maskę snopu

varying vec2 texcoord;

const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);

// Filmic ACES (aproksymacja Narkowicza) — chroni highlighty (latarka zostaje jasna).
vec3 acesFilmic(vec3 x) {
    const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

// Maska snopu latarki (0..1) — powielona z composite.fsh (kąt promienia od osi -Z kamery), by
// final mógł stosować OSOBNY kontrast w snopie vs poza nim. Poza snopem / bez latarki = 0.
float flashlightBeamMask(vec2 uv) {
    if (heldItemId != FLASHLIGHT_ID) return 0.0;
    vec4 farClip = vec4(uv * 2.0 - 1.0, 1.0, 1.0);
    vec4 farV = gbufferProjectionInverse * farClip;
    vec3 rayDir = normalize(farV.xyz / farV.w);
    float cosAng = -rayDir.z;                    // 1.0 = prosto w osi latarki
    float inner = radians(FLASHLIGHT_ANGLE * (1.0 - FLASHLIGHT_SOFT));
    float outer = radians(FLASHLIGHT_ANGLE * (1.0 + FLASHLIGHT_SOFT));
    return smoothstep(cos(outer), cos(inner), cosAng);
}

void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;

    // fx = siła całego tonemapu urbex. Z URBEX_DAY_PROTECT działa TYLKO w nocy — w dzień fx=0, więc
    // obraz przechodzi 1:1 (waniliowa jasność/kolor w dzień; config obowiązuje tylko w ciemności).
    // Bez URBEX_DAY_PROTECT fx=1 zawsze (stare zachowanie).
#ifdef URBEX_DAY_PROTECT
    float t = mod(float(worldTime), 24000.0);
    // noc ~ [13000,23000]; łagodne przejścia: zmierzch (12000→13500) i świt (22500→23400).
    float fx = smoothstep(12000.0, 13500.0, t) * (1.0 - smoothstep(22500.0, 23400.0, t));
#else
    float fx = 1.0;
#endif

    // Ekspozycja + realne przyciemnienie nocy (naprawia prześwietloną, płaską noc na dworze;
    // URBEX_NIGHT_DARKNESS = suwak „jak ciemno w nocy"). Oba bramkowane fx → w dzień bez zmian.
    col *= mix(1.0, URBEX_EXPOSURE, fx);
    col *= mix(1.0, URBEX_NIGHT_DARKNESS, fx);

    // Rolloff prześwietleń: łagodnie ściąga jasne wartości (>~0.75), by rdzeń snopu i highlighty
    // nie przepalały się na płaską biel → więcej kontrastu „w wyższych partach". Bramkowany fx.
    col = col / (1.0 + (URBEX_HIGHLIGHT_ROLLOFF * fx) * max(col - vec3(0.75), 0.0));

    // Maska cieni z jasności otoczenia (1 w cieniach, 0 w średnich/jasnych).
    float lum = dot(col, LUMA);
    float shadow = 1.0 - smoothstep(0.0, 0.35, lum);

    // Shadow-crush: przygaś cienie (mocniejsza czerń).
    col *= mix(1.0, 1.0 - URBEX_SHADOW_CRUSH, shadow * fx);

    // Zimna tonacja cieni (urbex): lekko niebieskie cienie, highlighty bez zmian.
    vec3 cold = vec3(0.82, 0.94, 1.18);
    col = mix(col, col * cold, shadow * URBEX_COLD_SHADOWS * fx);

    // Krzywa kontrastu wokół liniowej szarości ~0.18 (bramkowana fx → w dzień bez zmian).
    // Kontrast rozdzielony: rdzeń snopu latarki = URBEX_CONTRAST_BEAM, reszta kadru = URBEX_CONTRAST_AMBIENT.
    float beam = flashlightBeamMask(texcoord);
    float contrast = mix(URBEX_CONTRAST_AMBIENT, URBEX_CONTRAST_BEAM, beam);
    col = mix(col, mix(vec3(0.18), col, contrast), fx);
    col = max(col, vec3(0.0));

    // Filmic tonemap (przełącznik w panelu Iris; bramkowany fx → dzień waniliowy).
#ifdef TONEMAP_ACES
    col = mix(col, acesFilmic(col), fx);
#else
    col = clamp(col, 0.0, 1.0);
#endif

    // Winieta (przyciemnij rogi; bramkowana fx).
    float d = length(texcoord - 0.5);
    float vig = mix(1.0, smoothstep(0.90, 0.35, d), VIGNETTE * fx);
    col *= vig;

    // Subtelny film grain (animowany frameTimeCounter; bramkowany fx).
    float g = hash21(texcoord * vec2(viewWidth, viewHeight) + fract(frameTimeCounter) * 60.0);
    col += (g - 0.5) * FILM_GRAIN * fx;

    gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
