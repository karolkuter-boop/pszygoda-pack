/*
 * VerityUrbex — wspólne ustawienia shadera (opcje panelu Iris).
 * Dołączane przez composite (reflektor) i final (tonemap). Wszystkie wartości są opcjami
 * konfigurowalnymi w panelu Iris (patrz shaders.properties: screen/sliders + lang).
 *
 * (c) 2026 FFTV — All Rights Reserved. Autorski pack, bez zależności od cudzego kodu.
 */
#ifndef VERITY_SETTINGS_GLSL
#define VERITY_SETTINGS_GLSL

// ── Reflektor / snop latarki (zadanie 4) ─────────────────────────────────────
#define FLASHLIGHT_INTENSITY 1.75   // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.6 1.75 2.0 2.5 3.0]
#define FLASHLIGHT_RANGE     20.0   // [8.0 10.0 12.0 14.0 16.0 18.0 20.0 22.0 26.0 30.0 40.0]
#define FLASHLIGHT_ANGLE     18.0   // [10.0 12.0 14.0 16.0 18.0 20.0 24.0 28.0 32.0 40.0] stopnie, pół-kąt stożka
#define FLASHLIGHT_SOFT      0.3    // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.45 0.6 0.8] miękkość krawędzi
#define FLASHLIGHT_TEMP      0.2    // [0.0 0.05 0.1 0.15 0.2 0.3 0.4] ciepłota rdzenia (0=biały)
#define FLASHLIGHT_ID        4001   // heldItemId dla pszygoda:latarka (patrz item.properties)

// ── Nocny urbex tonemap (zadania 5–6) ────────────────────────────────────────
#define TONEMAP_ACES                // filmic ACES on/off — zakomentuj by wyłączyć
#define URBEX_CONTRAST       1.25   // [1.0 1.05 1.1 1.15 1.18 1.25 1.35 1.5]
#define URBEX_SHADOW_CRUSH   0.14   // [0.0 0.05 0.08 0.1 0.14 0.2 0.28] podbicie czerni
#define URBEX_COLD_SHADOWS   0.35   // [0.0 0.1 0.2 0.25 0.35 0.5] zimna tonacja cieni
#define URBEX_EXPOSURE       0.9    // [0.7 0.8 0.9 1.0 1.1 1.2 1.35]
#define VIGNETTE             0.35   // [0.0 0.15 0.25 0.35 0.5 0.7] siła winiety
#define FILM_GRAIN           0.025  // [0.0 0.015 0.025 0.035 0.05 0.08] ziarno

#endif // VERITY_SETTINGS_GLSL
