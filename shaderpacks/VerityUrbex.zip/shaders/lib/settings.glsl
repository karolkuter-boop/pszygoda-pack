/*
 * VerityUrbex — wspólne ustawienia shadera (opcje panelu Iris).
 * Dołączane przez composite (reflektor) i final (tonemap). Wszystkie wartości są opcjami
 * konfigurowalnymi w panelu Iris (patrz shaders.properties: screen/sliders + lang).
 *
 * (c) 2026 FFTV — All Rights Reserved. Autorski pack, bez zależności od cudzego kodu.
 */
#ifndef VERITY_SETTINGS_GLSL
#define VERITY_SETTINGS_GLSL

// ── Reflektor / snop latarki (zadanie 4) ─────────────────────────────────────
#define FLASHLIGHT_INTENSITY 2.0    // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.6 1.75 2.0 2.5 3.0]
#define FLASHLIGHT_RANGE     20.0   // [8.0 10.0 12.0 14.0 16.0 18.0 20.0 22.0 26.0 30.0 40.0]
#define FLASHLIGHT_ANGLE     18.0   // [10.0 12.0 14.0 16.0 18.0 20.0 24.0 28.0 32.0 40.0] stopnie, pół-kąt stożka
#define FLASHLIGHT_SOFT      0.3    // [0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.45 0.6 0.8] miękkość krawędzi
#define FLASHLIGHT_TEMP      0.2    // [0.0 0.05 0.1 0.15 0.2 0.3 0.4] ciepłota rdzenia (0=biały)
#define FLASHLIGHT_ID        4001   // heldItemId dla pszygoda:latarka (patrz item.properties)

// ── Nocny urbex tonemap (zadania 5–6) ────────────────────────────────────────
// Feedback właściciela: heavy „graded/matowy" look źle wygląda — ma być SUBTELNIE, blisko vanilla.
// Dlatego domyślnie: ACES OFF, ziarno 0, ledwie zimne cienie, delikatny kontrast/winieta. Zostaje
// tylko łagodne przyciemnienie nocy + anty-przepał snopu. Kto chce mocny look → profil URBEX w panelu.
//#define TONEMAP_ACES              // filmic ACES — DOMYŚLNIE OFF (dawał matowy/milky look); włącz w panelu
#define URBEX_DAY_PROTECT           // ON: cały tonemap działa TYLKO w nocy — dzień zostaje waniliowy
                                     //     (życzenie: shadery nie ruszają jasności/wyglądu w dzień)
#define URBEX_NIGHT_DARKNESS 0.7    // [0.35 0.45 0.55 0.65 0.7 0.75 0.85 1.0] jak ciemno w nocy (1=bez przyciemnienia; niżej = ciemniej)
#define URBEX_HIGHLIGHT_ROLLOFF 0.5 // [0.0 0.25 0.4 0.5 0.6 0.8 1.0 1.5] ściąganie prześwietleń (snop nie przepala się na płaską biel)
// Kontrast rozdzielony na dwie strefy (zadanie: osobna kontrolka przy latarce vs poza snopem).
// final.fsh liczy maskę stożka latarki (jak composite) i miesza kontrast: rdzeń snopu = BEAM,
// reszta kadru = AMBIENT. Gdy latarki nie ma w ręce, cały kadr używa AMBIENT (kompatybilnie ze
// starym pojedynczym URBEX_CONTRAST — dlatego oba defaulty = 1.1).
#define URBEX_CONTRAST_BEAM    1.1  // [1.0 1.05 1.1 1.15 1.18 1.25 1.3 1.35 1.5] kontrast W snopie latarki
#define URBEX_CONTRAST_AMBIENT 1.1  // [1.0 1.05 1.1 1.15 1.18 1.25 1.3 1.35 1.5] kontrast POZA snopem latarki
#define URBEX_SHADOW_CRUSH   0.05   // [0.0 0.05 0.08 0.1 0.14 0.2 0.28] podbicie czerni
#define URBEX_COLD_SHADOWS   0.1    // [0.0 0.1 0.2 0.25 0.35 0.5] zimna tonacja cieni (ledwie — mniej „milky")
#define URBEX_EXPOSURE       1.0    // [0.7 0.8 0.9 1.0 1.1 1.2 1.35] bez cięcia ekspozycji
#define VIGNETTE             0.15   // [0.0 0.15 0.25 0.35 0.5 0.7] subtelna winieta
#define FILM_GRAIN           0.0    // [0.0 0.015 0.025 0.035 0.05 0.08] ziarno (0 = bez „matowego" nalotu)

#endif // VERITY_SETTINGS_GLSL
