#version 120
/* VerityUrbex — composite pass (reflektor latarki). Fullscreen quad. */
varying vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
}
