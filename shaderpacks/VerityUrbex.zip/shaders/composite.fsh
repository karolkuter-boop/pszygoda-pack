#version 120
/*
 * VerityUrbex — composite: REFLEKTOR / snop latarki (zadanie 4).
 *
 * Realny stożek światła w przestrzeni KAMERY (wierzchołek = kamera, oś = forward = -Z view space).
 * Dla każdego piksela:
 *   1) liczymy kierunek promienia widoku z gbufferProjectionInverse → kąt od osi → maska stożka
 *      (miękka krawędź). To kształt SNOPU.
 *   2) rekonstruujemy pozycję trafionej powierzchni z depthtex0 → oświetlamy JĄ (zanik ~kwadratowy
 *      z odległością, N·L z normalnej z pochodnych głębi). Bo lightujemy realnie widoczną powierzchnię
 *      per piksel, światło NIE prześwietla ścian (ściana z przodu zasłania głębię dalszych obiektów).
 *   3) dokładamy subtelny człon objętościowy (haze) wzdłuż promienia w granicach stożka i zasięgu —
 *      żeby snop był WIDOCZNY też w powietrzu (życzenie właściciela: „wyraźny snop").
 * Rdzeń ciepło-biały (FLASHLIGHT_TEMP). Całość bramkowana po heldItemId == latarka (item.properties).
 *
 * (c) 2026 FFTV — All Rights Reserved.
 */
#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform int heldItemId;
uniform int heldBlockLightValue;

varying vec2 texcoord;

/* DRAWBUFFERS:0 */

// Wewnętrzne stałe snopu (strojenie zadanie 6 może je przenieść do settings.glsl).
// Feedback właściciela: „bardziej snopem światła wyraźnym" → mocniejszy, bardziej widoczny snop.
const float HAZE_STRENGTH = 0.18;   // siła widocznego snopu w powietrzu (podbite: wyraźniejszy snop)
const float HAZE_K        = 0.07;   // narastanie haze z długością promienia (szybszy build snopu)
const float AMBIENT_FLOOR = 0.35;   // ile światła dostają powierzchnie „bokiem" do latarki

vec3 viewFromClip(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 v = gbufferProjectionInverse * clip;
    return v.xyz / v.w;
}

void main() {
    vec3 scene = texture2D(colortex0, texcoord).rgb;

    // Bramka: rysuj snop tylko gdy latarka jest w ręce (heldItemId z item.properties).
    if (heldItemId != FLASHLIGHT_ID) {
        gl_FragColor = vec4(scene, 1.0);
        return;
    }

    // (1) Kierunek promienia widoku przez ten piksel (do dalekiej płaszczyzny) i kąt od osi -Z.
    vec4 farClip = vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
    vec4 farV = gbufferProjectionInverse * farClip;
    vec3 rayDir = normalize(farV.xyz / farV.w);
    float cosAng = -rayDir.z;                    // 1.0 = prosto w osi latarki

    float inner = radians(FLASHLIGHT_ANGLE * (1.0 - FLASHLIGHT_SOFT));
    float outer = radians(FLASHLIGHT_ANGLE * (1.0 + FLASHLIGHT_SOFT));
    float mask = smoothstep(cos(outer), cos(inner), cosAng);
    if (mask <= 0.0) {
        gl_FragColor = vec4(scene, 1.0);
        return;
    }

    // (2) Oświetlenie trafionej powierzchni (pomijamy niebo: depth == 1.0).
    float depth = texture2D(depthtex0, texcoord).r;
    float lit = 0.0;
    float rayLen = FLASHLIGHT_RANGE;
    if (depth < 1.0) {
        vec3 P = viewFromClip(texcoord, depth);
        float dist = length(P);
        rayLen = min(dist, FLASHLIGHT_RANGE);
        float att = clamp(1.0 - dist / FLASHLIGHT_RANGE, 0.0, 1.0);
        att *= att;                              // zanik ~kwadratowy
        vec3 N = normalize(cross(dFdx(P), dFdy(P)));
        vec3 L = normalize(-P);                  // od powierzchni do kamery/latarki (w 0,0,0)
        float ndl = mix(AMBIENT_FLOOR, 1.0, max(dot(N, L), 0.0));
        lit = att * ndl;
    }

    // (3) Objętościowy snop w powietrzu (widoczny nawet bez trafionej powierzchni w zasięgu).
    float haze = (1.0 - exp(-rayLen * HAZE_K)) * HAZE_STRENGTH;

    // Ciepło-biały rdzeń; jasność rdzenia rośnie ku osi (wyraźny gorący rdzeń snopu).
    vec3 warm = mix(vec3(1.0), vec3(1.0, 0.86, 0.62), clamp(FLASHLIGHT_TEMP * 2.0, 0.0, 1.0));
    float core = 0.8 + 0.7 * smoothstep(cos(inner), 1.0, cosAng); // gorętszy, bardziej wyrazisty rdzeń
    // Opcjonalny wzmacniacz ON: jeśli klient/mixin poda heldBlockLightValue>0 — rozjaśnij rdzeń.
    float onBoost = 1.0 + clamp(float(heldBlockLightValue) / 15.0, 0.0, 1.0) * 0.5;

    float amount = mask * FLASHLIGHT_INTENSITY * core * onBoost * (lit + haze);
    vec3 outCol = scene + warm * amount;

    gl_FragColor = vec4(outCol, 1.0);
}
