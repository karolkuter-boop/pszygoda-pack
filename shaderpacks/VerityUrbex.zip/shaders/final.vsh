#version 120
/* VerityUrbex — final pass (fullscreen). Wierzchołki fullscreen quada Iris. */
varying vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
}
