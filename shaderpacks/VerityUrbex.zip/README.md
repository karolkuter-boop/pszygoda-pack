# VerityUrbex — shaderpack Iris (nocny urbex + snop latarki)

Autorski shaderpack FFTV do produkcji „Verity". Napisany od zera pod **Iris + Sodium, Minecraft
1.21.1** (bez forka, bez cudzego kodu). Daje:

- **Snop latarki** — realny stożek światła w przestrzeni kamery (composite), maskowany po głębi
  (nie prześwietla ścian), ciepło‑biały rdzeń, konfigurowalna siła/zasięg/kąt/miękkość.
- **Nocny urbex tonemap** (final) — filmowy ACES, mocny kontrast, podbicie i zimna tonacja cieni,
  winieta, subtelne ziarno.

## Struktura

```
VerityUrbex/
  shaders/
    shaders.properties     — panel opcji (screen/sliders/profile)
    item.properties        — most latarki: item.4001 = pszygoda:latarka -> heldItemId
    lib/settings.glsl      — wszystkie opcje (#define, współdzielone przez pass-y)
    composite.vsh/.fsh     — reflektor / snop latarki
    final.vsh/.fsh         — urbex tonemap
    lang/{en_us,pl_pl}.lang
  LICENSE
```

## Most ON/OFF (skrót)

Shader wykrywa latarkę w ręce po `heldItemId == 4001` (mapowanie w `item.properties`). Podwójne
światło (bloki `minecraft:light` vs snop shadera) rozwiązuje mod: klient z aktywnym Iris melduje to
serwerowi (`ShaderStateC2S`), a `FlashlightManager` przestaje stawiać bloki światła. Bez Iris —
fallback blokowy jak dotąd. Pełne rozróżnienie ON/OFF gdy latarka trzymana wymaga klienckiego
mixinu w Iris (patrz `docs/shader/iris-1.21.1-research.md` w repo moda).

## Włączenie w grze

1. Zainstaluj **Sodium + Iris** (w modpacku Pszygoda dochodzą automatycznie).
2. Wrzuć `VerityUrbex.zip` (albo folder `VerityUrbex/`) do `shaderpacks/` instancji.
   W modpacku Pszygoda pack leci auto‑downloadem — patrz dystrybucja (zadanie 7).
3. W grze: **Opcje → Ustawienia grafiki → Shadery (Iris)** → wybierz `VerityUrbex` → Zastosuj.
4. Weź latarkę (`pszygoda:latarka`), PPM = włącz. Snop pojawia się gdy latarka jest w ręce.

© 2026 FFTV — All Rights Reserved.
